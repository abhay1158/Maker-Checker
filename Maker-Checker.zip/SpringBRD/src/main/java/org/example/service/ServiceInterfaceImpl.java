package org.example.service;

import org.example.dao.Dao;
import org.example.model.CustomerMaster;
import org.example.model.CustomerTemp;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@org.springframework.stereotype.Service
public class ServiceInterfaceImpl implements ServiceInterface {


    @Autowired
    private Dao dao;

    @Override
    public boolean makerAddsCustomerInTempTable(CustomerTemp customerTemp) {
        return dao.makerAddsCustomerInTempTable(customerTemp);
    }

    @Override
    public boolean makerModifiesANewRecordTempTable(CustomerTemp customerTemp) {
        return dao.makerModifiesANewRecordTempTable(customerTemp);

    }

    @Override
    public boolean makerDeleteNewRecordTempTable(String customerCode) {
        return dao.makerDeleteNewRecordTempTable(customerCode);

    }

    @Override
    public List<CustomerTemp> makerViewAllRecordsTempTable() {
        return dao.makerViewAllRecordsTempTable();
    }

    @Override
    public CustomerTemp makerGetCustomerFromTemp(String customerCode) {
        return dao.makerGetCustomerFromTemp(customerCode);
    }

    @Override
    public List<CustomerMaster> makerViewAllRecordsMasterTable() {
        return dao.makerViewAllRecordsMasterTable();
    }

    @Override
    public CustomerMaster makerGetCustomerFromMaster(String customerCode) {
        return dao.makerGetCustomerFromMaster(customerCode);
    }

    @Override
    public long findTheLatestInsertedRowNumberTempTable() {
        return dao.findTheLatestInsertedRowNumberTempTable();
    }

    /* --------------------------------- Checker Actions --------------------------*/

    @Override
    public List<CustomerTemp> checkerViewAllRecordsTempTable() {
        return dao.checkerViewAllRecordsTempTable();
    }

    @Override
    public CustomerTemp checkerGetCustomerFromTemp(String customerCode) {
        return dao.checkerGetCustomerFromTemp(customerCode);
    }

    @Override
    public CustomerMaster checkerModifiesANewRecordMasterTable(CustomerMaster customerMaster) {
        return dao.checkerModifiesANewRecordMasterTable(customerMaster);
    }

    @Override
    public CustomerTemp checkerModifiesANewRecordTempTable(CustomerTemp customerTemp) {
        return dao.checkerModifiesANewRecordTempTable(customerTemp);
    }

    @Override
    public boolean checkerAddsCustomerInMasterTable(CustomerMaster customerMaster) {
        return dao.checkerAddsCustomerInMasterTable(customerMaster);
    }

    @Override
    public boolean checkerDeleteNewRecordMasterTable(String customerCode) {
        return dao.checkerDeleteNewRecordMasterTable(customerCode);
    }
}
