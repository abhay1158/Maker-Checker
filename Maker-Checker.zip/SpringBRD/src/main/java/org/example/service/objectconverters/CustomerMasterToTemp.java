package org.example.service.objectconverters;

import org.example.model.CustomerMaster;
import org.example.model.CustomerTemp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CustomerMasterToTemp {


    public static CustomerTemp copyToTemp(CustomerMaster customerMaster) {

        CustomerTemp customerTemp1 = new CustomerTemp();

        customerTemp1.setCustomerId(customerMaster.getCustomerId());

        customerTemp1.setCustomerCode(customerMaster.getCustomerCode());

        customerTemp1.setCustomerName(customerMaster.getCustomerName());

        customerTemp1.setCustomerAddress1(customerMaster.getCustomerAddress1());

        customerTemp1.setCustomerAddress2(customerMaster.getCustomerAddress2());

        customerTemp1.setPinCode(customerMaster.getPinCode());

        customerTemp1.setEmailAddress(customerMaster.getEmailAddress());

        customerTemp1.setContactNumber(customerMaster.getContactNumber());

        customerTemp1.setPrimaryContactPerson(customerMaster.getPrimaryContactPerson());

        customerTemp1.setRecordStatus(customerMaster.getRecordStatus());

        customerTemp1.setActiveInactiveFlag(customerMaster.getActiveInactiveFlag());

        customerTemp1.setCreatedBy(customerMaster.getCreatedBy());

        customerTemp1.setCreateDate(customerMaster.getCreateDate());

        customerTemp1.setModifiedBy(customerMaster.getModifiedBy());
        customerTemp1.setModifiedDate(customerMaster.getModifiedDate());
        customerTemp1.setAuthorizedBy(customerMaster.getAuthorizedBy());
        customerTemp1.setAuthorizedDate(customerMaster.getAuthorizedDate());

        return customerTemp1;
    }
}
