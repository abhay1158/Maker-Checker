package org.example.service.objectconverters;

import org.example.model.CustomerMaster;
import org.example.model.CustomerTemp;
import org.springframework.stereotype.Component;

@Component
public class CustomerTempIntoMaster {
    public static CustomerMaster copyToMaster(CustomerTemp customerTemp) {
        CustomerMaster customerMaster  = new CustomerMaster();

        customerMaster.setCustomerId(customerTemp.getCustomerId());

        customerMaster.setCustomerCode(customerTemp.getCustomerCode());

        customerMaster.setCustomerName(customerTemp.getCustomerName());

        customerMaster.setCustomerAddress1(customerTemp.getCustomerAddress1());

        customerMaster.setCustomerAddress2(customerTemp.getCustomerAddress2());

        customerMaster.setPinCode(customerTemp.getPinCode());

        customerMaster.setEmailAddress(customerTemp.getEmailAddress());

        customerMaster.setContactNumber(customerTemp.getContactNumber());

        customerMaster.setPrimaryContactPerson(customerTemp.getPrimaryContactPerson());

        customerMaster.setRecordStatus(customerTemp.getRecordStatus());

        customerMaster.setActiveInactiveFlag(customerTemp.getActiveInactiveFlag());

        customerMaster.setCreatedBy(customerTemp.getCreatedBy());

        customerMaster.setCreateDate(customerTemp.getCreateDate());

        customerMaster.setModifiedBy(customerTemp.getModifiedBy());
        customerMaster.setModifiedDate(customerTemp.getModifiedDate());
        customerMaster.setAuthorizedBy(customerTemp.getAuthorizedBy());
        customerMaster.setAuthorizedDate(customerTemp.getAuthorizedDate());

        return customerMaster;
    }
}
