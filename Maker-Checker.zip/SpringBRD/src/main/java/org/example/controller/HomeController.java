package org.example.controller;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.model.CustomerMaster;
import org.example.model.CustomerTemp;
import org.example.service.ServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private ServiceInterface serviceInterface;
    Logger logger = LogManager.getLogger(this.getClass());

    // this is only for the jdbc authentication
    @GetMapping(value = "/loginPage")
    public String loginMethod(ModelMap mp) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth.getAuthorities().stream().anyMatch(role -> role.getAuthority().equals("CHECKER"))) {
            logger.info(auth.getName() + "Logged In");

            List<CustomerTemp> customerTemp =  serviceInterface.checkerViewAllRecordsTempTable();

            mp.addAttribute("currentuser", auth.getName());
            mp.addAttribute("listOfCustomersChecker", customerTemp);

            return "checker/checkerHome";
        }

        // this is for maker
        List<CustomerTemp> customerTemp =  serviceInterface.makerViewAllRecordsTempTable();
        List<CustomerMaster> customerMasters =  serviceInterface.makerViewAllRecordsMasterTable();

        mp.addAttribute("currentuser", auth.getName());
        mp.addAttribute("listOfCustomersMaker", customerTemp);
        mp.addAttribute("listOfCustomersMaster", customerMasters);

        logger.info(auth.getName() + "Logged In");
        mp.addAttribute("currentuser", auth.getName());
        return "maker/makerHome";
    }

}
