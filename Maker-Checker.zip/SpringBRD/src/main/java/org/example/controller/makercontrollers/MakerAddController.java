package org.example.controller.makercontrollers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.model.CustomerMaster;
import org.example.model.CustomerTemp;
import org.example.model.FileUpload;
import org.example.model.ReadFileData;
import org.example.model.custompropertyeditors.DateConverter;
import org.example.model.custompropertyeditors.NumberFormatExceptionConverter;
import org.example.service.ServiceInterface;
import org.example.service.objectconverters.CustomerMasterToTemp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.time.LocalDate;
import java.util.List;

@Controller
public class MakerAddController {

    Logger logger = LogManager.getLogger(this.getClass());


    //    init binder for the customise data format
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(LocalDate.class, new DateConverter());
        binder.registerCustomEditor(Double.TYPE, new NumberFormatExceptionConverter());
    }

    private String makerRecordDisplayPage = "maker/recordDisplayPage";
    private String customersFormData = "customersFormData";
    private String messageFromPage = "messageFromPage";

    @Autowired
    private ServiceInterface serviceInterface;

    @Autowired
    private ReadFileData readFileData;

    @GetMapping("maker/makerPage")
    public String makerHome() {
        return "maker/makerHome";
    }

    // mapping for the add Customer
    @GetMapping("maker/addCustomer")
    public String addCustomer(ModelMap mv) {
        CustomerTemp customerTemp = new CustomerTemp();
        long currentCustomerId = serviceInterface.findTheLatestInsertedRowNumberTempTable();
        customerTemp.setCustomerId(currentCustomerId + 1);
        mv.put("customerTemp", customerTemp);
        mv.put("message", "Registration");
        return "maker/registerCustomerForm";
    }


    // for the save Button
    @PostMapping(value = "maker/addCustomer")
    public String saveCustomerForm(@Valid @ModelAttribute("customerTemp") CustomerTemp customerTemp, BindingResult bindingResult, ModelMap mv) {

        if (bindingResult.hasErrors() || serviceInterface.makerGetCustomerFromTemp(customerTemp.getCustomerCode()) != null) {
            mv.addAttribute("message", "Registration");
            mv.addAttribute("alreadyExists", "Customer Code Already Exists !!");
            return "maker/registerCustomerForm";
        }
        mv.addAttribute("customerFilledData", customerTemp);
        return "maker/chooseOptionsForSave";
    }


    //    if maker choose no for the submission of data
    @PostMapping(value = "maker/addCustomer", params = "noButton")
    public String dataNotSave(HttpSession session, ModelMap model) {
        CustomerTemp customerTemp1 = (CustomerTemp) session.getAttribute("customerData");
        model.addAttribute("message", "Registration");
        model.put("customerTemp", customerTemp1);
        return "maker/registerCustomerForm";
    }


    //     if maker choose yes for the submission of data
    @PostMapping(value = "maker/addCustomer", params = "yesButton")
    public String dataSave(HttpSession session, ModelMap mp) {
        //it will take all the data filled by the maker
        CustomerTemp customerTemp = (CustomerTemp) session.getAttribute("customerData");
        //        for getting the name of current user in the session
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        customerTemp.setRecordStatus("N");
        customerTemp.setCreatedBy(auth.getName());

        serviceInterface.makerAddsCustomerInTempTable(customerTemp);

        mp.put(customersFormData, customerTemp);
        return "maker/customersDataSave";
    }


    // Delete Button on maker home page
    @GetMapping(value = "maker/deleteButton/{customerCode}")
    public String deleteCustomerButton(@PathVariable("customerCode") String customerCode, ModelMap mp) {
        CustomerTemp deletedCustomerInTemp = serviceInterface.makerGetCustomerFromTemp(customerCode);
        CustomerMaster customerInMaster = serviceInterface.makerGetCustomerFromMaster(customerCode);

        mp.put(messageFromPage, "Record Deleted Successfully (*_*)");

        // delete from dao

/*-----------------------> 1- Maker Deletes a New record (N ->D) or 2 -  Maker Deletes a Modified record (A ->M ->D) or 3 - Maker Deletes a new Rejected record (N ->NR ->D)
4 - Maker Deletes a Modified Rejected record (N ->MR ->D)
*/
        if (deletedCustomerInTemp != null && !deletedCustomerInTemp.getRecordStatus().equals("A")) {
            // although we don't need to change the status by D because in the end it gets deleted
            deletedCustomerInTemp.setRecordStatus("D");
            serviceInterface.makerDeleteNewRecordTempTable(customerCode);
            mp.put(customersFormData, deletedCustomerInTemp);
            return makerRecordDisplayPage;
        }
// ----------------------->  5 - Maker Deletes an Authorized record (A ->D) - it is for master table

        else if (customerInMaster != null && customerInMaster.getRecordStatus().equals("A")) {
            // although we don't need to change the status by D because in the end it gets deleted

            deletedCustomerInTemp = CustomerMasterToTemp.copyToTemp(customerInMaster);

            deletedCustomerInTemp.setRecordStatus("D");

            // if data doesn't present in the temp table
            CustomerTemp currentCustomerInTemp = serviceInterface.makerGetCustomerFromTemp(deletedCustomerInTemp.getCustomerCode());
            if (currentCustomerInTemp == null) serviceInterface.makerAddsCustomerInTempTable(deletedCustomerInTemp);
            else serviceInterface.makerModifiesANewRecordTempTable(deletedCustomerInTemp);
//            here we do not delete this customer from the temp table just update the status by D there
            mp.put(customersFormData, deletedCustomerInTemp);

        }

        return makerRecordDisplayPage;
    }


    // Modify button on maker home page
    @GetMapping(value = "maker/modifyButton/{customerCode}")
    public String modifyCustomerButton(@PathVariable("customerCode") String customerCode, ModelMap mp) {
        CustomerTemp customerToModify = serviceInterface.makerGetCustomerFromTemp(customerCode);

        CustomerMaster customerToModifyInMaster = serviceInterface.makerGetCustomerFromMaster(customerCode);

        mp.addAttribute("message", "Modification");

        if (customerToModify != null && !customerToModify.getRecordStatus().equals("A")) {

            mp.put("customerTemp", customerToModify);
            return "maker/customerDataModification";
        } else if (customerToModifyInMaster != null && customerToModifyInMaster.getRecordStatus().equals("A")) {
            customerToModify = CustomerMasterToTemp.copyToTemp(customerToModifyInMaster);
            mp.put("customerTemp", customerToModify);

        }

        return "maker/customerDataModification";


    }


    //    this is for the final save button :

    @PostMapping(value = "maker/modifyButton/{customerCode}", params = "finalSaveButton")
    public String finalSavedData(@ModelAttribute("customerTemp") CustomerTemp customerTemp1, ModelMap mp) {
        mp.put(customersFormData, customerTemp1);
        return "maker/chooseOptionsForFinalSave";
    }

    //    this is for the final save button if maker selects No then:
    @PostMapping(value = "maker/modifyButton/{customerCode}", params = "noFinalButton")
    public String makerChooseFinalNo(HttpSession session, ModelMap mp) {

        CustomerTemp customerTemp = (CustomerTemp) session.getAttribute("customerData");
        mp.put(messageFromPage, "Your Pre-filled Data,Choosed NO !! ");
        mp.put(customersFormData, customerTemp);
        return makerRecordDisplayPage;
    }


    //    this is for the final save button if maker selects Yes then:
    @PostMapping(value = "maker/modifyButton/{customerCode}", params = "yesFinalButton")
    public String makerChooseFinalYes(HttpSession session, ModelMap mp) {
        CustomerTemp customerTemp = (CustomerTemp) session.getAttribute("customerData");

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

//-----------------------> 1 - Maker Modifies a New record(N ->M)

        if (customerTemp.getRecordStatus().equals("N")) {
            customerTemp.setRecordStatus("M");
            customerTemp.setModifiedBy(auth.getName());
            customerTemp.setModifiedDate(LocalDate.now());
            serviceInterface.makerModifiesANewRecordTempTable(customerTemp);
        }

//-----------------------> 2 - Maker Modifies a Modified authorized record (A ->M ->M)

        if (customerTemp.getRecordStatus().equals("A") || customerTemp.getRecordStatus().equals("M")) {
//          first insert this data into the temporary table with the status M
            customerTemp.setRecordStatus("M");
            customerTemp.setModifiedBy(auth.getName());
            customerTemp.setModifiedDate(LocalDate.now());

            // if data doesnot present in the temp table
            CustomerTemp currentCustomerInTemp = serviceInterface.makerGetCustomerFromTemp(customerTemp.getCustomerCode());
            if (currentCustomerInTemp == null) serviceInterface.makerAddsCustomerInTempTable(customerTemp);
            else serviceInterface.makerModifiesANewRecordTempTable(customerTemp);
        }


//-----------------------> 3 - Maker Modifies a new Rejected record (N ->NR ->M) or 4 - Maker Modifies a Modified Rejected record (N ->MR ->M)
        if (customerTemp.getRecordStatus().equals("NR") || customerTemp.getRecordStatus().equals("MR") || customerTemp.getRecordStatus().equals("DR")) {
            customerTemp.setRecordStatus("M");
            serviceInterface.makerModifiesANewRecordTempTable(customerTemp);
        }

        mp.put(messageFromPage, "Record Modified - Final Data ");
        mp.put(customersFormData, customerTemp);
        return makerRecordDisplayPage;
    }


    //    for the cancel Button in the modification page

    @PostMapping(value = "maker/modifyButton/{customerCode}", params = "cancelButton")
    public String cancelAndGetPrefilledData(@ModelAttribute("customerTemp") CustomerTemp customerTemp1, ModelMap mp) {
        mp.put(messageFromPage, " Hey ! This is Your Pre-filled Data ");
        mp.put(customersFormData, customerTemp1);
        return makerRecordDisplayPage;
    }

    //    for the cancel Button
    @GetMapping(value = "maker/loginPage")
    public String cancelCustomerForm() {
        return "maker/makerHome";
    }


    //    --------------------- For Uploading File ---------------
    @GetMapping("maker/uploadFileData")
    String uploadFileData(ModelMap model) {
        FileUpload fileUpload = new FileUpload();
        model.addAttribute("uploadedFile", fileUpload);
        return "maker/uploadFile";
    }


    @PostMapping("maker/uploadFileData")
    public String create(@ModelAttribute("uploadedFile") FileUpload fileUpload, ModelMap mp) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        logger.info("File Uploading ....");
        try {
            MultipartFile file = fileUpload.getFileData();
            List<CustomerTemp> customerTemps = readFileData.checkValidData(file);
            logger.info(customerTemps);
            for (CustomerTemp eachCustomerTemp : customerTemps) {
                eachCustomerTemp.setCreatedBy(auth.getName());
                eachCustomerTemp.setRecordStatus("N");
                serviceInterface.makerAddsCustomerInTempTable(eachCustomerTemp);
            }
//            if someone uploads different text file then how to handle that case ?
            mp.addAttribute("fileName", file.getOriginalFilename());
        } catch (Exception e) {
            logger.error(e);
        }
        return "maker/fileUploadedSuccess";
    }
}



    /*
     This is the code which i tried for the js confirmation instead of jsp pages but not works



    // for the save Button , if maker chooses YES
    @PostMapping(value = "maker/addCustomer")
    public String saveCustomerForm(@ModelAttribute("customerTemp") CustomerTemp customerTemp,ModelMap mp) {
//        ModelAndView mv = new ModelAndView();
//        mv.setViewName("maker/chooseOptionsForSave");
//        mv.addObject("customerFilledData", customerTemp);

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        customerTemp.setCreatedBy(auth.getName());

//        data added in the dB

        serviceInterface.makerAddsCustomerInTempTable(customerTemp);
        mp.put(customersFormData, customerTemp);
        return "maker/customersDataSave";
    }


    //    if maker choose no for the submission of data
    @PostMapping(value = "maker/addCustomerPreFilledData")
    public String dataNotSave(@ModelAttribute("customerTemp") CustomerTemp customerTemp,HttpSession session, ModelMap model) {
//        CustomerTemp customerTemp1 = (CustomerTemp) session.getAttribute("customerData");
        model.addAttribute("message", "Registration");
        model.put("customerTemp", customerTemp);
        return "maker/registerCustomerForm";
    }*/