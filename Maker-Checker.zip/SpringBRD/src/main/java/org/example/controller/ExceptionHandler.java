package org.example.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class ExceptionHandler implements HandlerExceptionResolver {

    Logger logger = LogManager.getLogger(this.getClass());
    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception error) {

        String s = String.format("Exception Handler: %s", handler);
        logger.info(s);
        logger.info(error);
        ModelAndView modelAndView = new ModelAndView();

        modelAndView.setViewName("exceptions/ExceptionErrorPage");
        modelAndView.addObject("name", error.getClass());
        modelAndView.addObject("errorHandler", error);

        return modelAndView;
    }
}