package org.example.controller.checkerControllers;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.model.CustomerMaster;
import org.example.model.CustomerTemp;
import org.example.service.ServiceInterface;
import org.example.service.objectconverters.CustomerTempIntoMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class CheckerAddController {
    Logger logger = LogManager.getLogger(this.getClass());
    @Autowired
    private ServiceInterface serviceInterface;
    @Autowired
    private CustomerTemp customerTemp;
    @Autowired
    private CustomerTempIntoMaster tempIntoMaster;

    //    home page
    @GetMapping(value = "checkerHomePage")
    public String cancelCustomerForm() {
        return "checker/checkerHome";
    }


    //    if checker authorizes
    @GetMapping(value = "checker/authorize/{customerCode}")
    public String customerAuthorized(@PathVariable("customerCode") String customerCode, ModelMap modelMap) {

        //        for getting the name of current user in the session
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();


        // get the customer by customerCode
        CustomerTemp customerTemp1 = serviceInterface.checkerGetCustomerFromTemp(customerCode);
        modelMap.addAttribute("customersFormData", customerTemp1);

//        now we have to play with the statuses of the customers record

// -----------------------> 1 - If Checker authorizes a new record(N ->A) or
// 5 - If Checker authorizes a modified record (A ->M ->A) , here 2nd condition in 2nd  checks whether it is preauthorize or not if it is then final authorize it by removing it from temp table

        if (customerTemp1.getRecordStatus().equals("N") || (customerTemp1.getRecordStatus().equals("M") && !customerTemp1.getAuthorizedBy().isEmpty())) {

            // now add this customer to the master table, so first copy the value into master type
            CustomerMaster customerMaster = tempIntoMaster.copyToMaster(customerTemp1);

            customerMaster.setRecordStatus("A");
            customerMaster.setAuthorizedBy(auth.getName());
//            add this customer into master table
            if (serviceInterface.makerGetCustomerFromMaster(customerMaster.getCustomerCode()) != null) serviceInterface.checkerModifiesANewRecordMasterTable(customerMaster);
            else serviceInterface.checkerAddsCustomerInMasterTable(customerMaster);

//            now hard delete it from the temporary table
            serviceInterface.makerDeleteNewRecordTempTable(customerTemp1.getCustomerCode());
        }


// -----------------------> 4 - If Checker authorizes a deleted record (A ->D ->A)
        if (customerTemp1.getRecordStatus().equals("D")) {

//            for this condition the customer will be removed from both the tables permanently
            serviceInterface.makerDeleteNewRecordTempTable(customerTemp1.getCustomerCode());

//            this need to be present in the master table on this case - (A ->D)
            serviceInterface.checkerDeleteNewRecordMasterTable(customerTemp1.getCustomerCode());
        }

        modelMap.addAttribute("messageFromPage", "Record Authorized");

        return "checker/recordDisplayPage";
    }


    //    if checker rejects
    @GetMapping(value = "checker/reject/{customerCode}")
    public String customerReject(@PathVariable("customerCode") String customerCode, ModelMap modelMap) {

        //        for getting the name of current user in the session
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();


        // get the customer by customerCode
        CustomerTemp customerTemp1 = serviceInterface.checkerGetCustomerFromTemp(customerCode);
        modelMap.addAttribute("customersFormData", customerTemp1);

//        now we have to play with the statuses of the customers record

// -----------------------> 2 - Checker Rejects a new record(N ->R)
        if (customerTemp1.getRecordStatus().equals("N")) {

//            for this condition the status of this customer in the temp table will be : NR
            customerTemp1.setRecordStatus("NR");

//            just change the status of the customer without adding into master table
            customerTemp1 = serviceInterface.checkerModifiesANewRecordTempTable(customerTemp1);
        }

// -----------------------> 3 - Checker rejects a modified record(M → R)

        if (customerTemp1.getRecordStatus().equals("M")) {
//            for this condition the status of this customer in the temp table will be : MR
            customerTemp1.setRecordStatus("MR");

            serviceInterface.checkerModifiesANewRecordTempTable(customerTemp1);

        }

// -----------------------> 6 - Checker rejects a deleted record (A->D->R)
        if (customerTemp1.getRecordStatus().equals("D")) {
//            for this condition the status of this customer in the temp table will be : MR
            customerTemp1.setRecordStatus("DR");
            serviceInterface.checkerModifiesANewRecordTempTable(customerTemp1);

        }

        modelMap.addAttribute("messageFromPage", "Record Rejected");

        return "checker/recordDisplayPage";
    }


}
