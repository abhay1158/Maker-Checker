package org.example.dao;


import org.example.model.CustomerMaster;
import org.example.model.CustomerTemp;

import java.util.List;

public interface Dao {
    /* --------------------------------- Maker Actions --------------------------*/

    //    Maker adds a new record
    boolean makerAddsCustomerInTempTable(CustomerTemp customerTemp);

    //    Maker modifies a new record
    boolean makerModifiesANewRecordTempTable(CustomerTemp customerTemp);

    //      Maker deletes a new Record
    boolean makerDeleteNewRecordTempTable(String customerCode);

    //      Maker views all Records from temp
    List<CustomerTemp> makerViewAllRecordsTempTable();

    //      Maker views all Records from master
    List<CustomerMaster> makerViewAllRecordsMasterTable();

    //      Maker get single Record from temp
    CustomerTemp makerGetCustomerFromTemp(String customerCode);

    //      Maker get single Record from master
    CustomerMaster makerGetCustomerFromMaster(String customerCode);

    //      Maker find the number of rows in the temp table for the current situation
    long findTheLatestInsertedRowNumberTempTable();


    /* --------------------------------- Checker Actions --------------------------*/
    //      Checker views all Records

    List<CustomerTemp> checkerViewAllRecordsTempTable();

    //      Checker get single Record

    CustomerTemp checkerGetCustomerFromTemp(String customerCode);

    //    checker modifies a new record in temp
    CustomerTemp checkerModifiesANewRecordTempTable(CustomerTemp customerTemp);

    //    checker modifies a new record in master
    CustomerMaster checkerModifiesANewRecordMasterTable(CustomerMaster customerMaster);

    //    checker adds a new record
    boolean checkerAddsCustomerInMasterTable(CustomerMaster customerMaster);

    //      Checker deletes a new Record
    boolean checkerDeleteNewRecordMasterTable(String customerCode);

}
