package org.example.dao.exceptions;

public class CustomerNotFoundException extends Exception{
    CustomerNotFoundException(){
        System.out.println("Customer not found !!");
    }
}
