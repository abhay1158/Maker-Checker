package org.example.dao;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.model.CustomerMaster;
import org.example.model.CustomerTemp;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.util.List;

@Repository
public class DaoImpl implements Dao {

    @Autowired
    private SessionFactory sessionFactory;

    Logger logger = LogManager.getLogger(this.getClass());

    /* --------------------------------- Maker Actions --------------------------*/

    //    Maker adds a new record
    @Override
    public boolean makerAddsCustomerInTempTable(CustomerTemp customerTemp) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        customerTemp.setCreateDate(LocalDate.now());

        session.save(customerTemp);

        transaction.commit();
        session.close();
        return true;
    }

    //    Maker modifies a new record
    @Override
    public boolean makerModifiesANewRecordTempTable(CustomerTemp customerTemp) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        customerTemp.setModifiedDate(LocalDate.now());
        session.update(customerTemp);
        transaction.commit();
        session.close();
        return true;
    }

    //      Maker deletes a new Record
    @Override
    public boolean makerDeleteNewRecordTempTable(String customerCode) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        CustomerTemp customer = session.get(CustomerTemp.class, customerCode);

        session.delete(customer);
        transaction.commit();
        session.close();
        return true;
    }

    //      Maker views all Records

    @Override
    public List<CustomerTemp> makerViewAllRecordsTempTable() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        List<CustomerTemp> customersList = session.createQuery("From CustomerTemp").list();

        transaction.commit();
        session.close();
        return customersList;
    }

    //      Maker get single Record from temp
    @Override
    public CustomerTemp makerGetCustomerFromTemp(String customerCode) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        CustomerTemp customer = session.get(CustomerTemp.class, customerCode);
        transaction.commit();
        session.close();
        return customer;
    }

    //      Maker views all Records from master
    @Override
    public List<CustomerMaster> makerViewAllRecordsMasterTable() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        List<CustomerMaster> customersList = session.createQuery("From CustomerMaster").list();

        transaction.commit();
        session.close();
        return customersList;
    }


    //      Maker get single Record from master
    @Override
    public CustomerMaster makerGetCustomerFromMaster(String customerCode) {
        Session session = sessionFactory.openSession();
        CustomerMaster customer = session.get(CustomerMaster.class, customerCode);
        session.close();
        return customer;
    }


    //      Maker find the number of rows in the temp table for the current situation
    @Override
    public long findTheLatestInsertedRowNumberTempTable() {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        CriteriaBuilder cb = session.getCriteriaBuilder();

        CriteriaQuery<Object> crt1 = cb.createQuery(Object.class);
        Root<CustomerTemp> root1 = crt1.from(CustomerTemp.class);
        crt1.select(cb.max(root1.get("customerId")));

        Query query = session.createQuery(crt1);
        Object lastRowInsertedInTemp = query.getSingleResult();

        CriteriaQuery<Object> crt2 = cb.createQuery(Object.class);
        Root<CustomerMaster> root2 = crt2.from(CustomerMaster.class);
        crt2.select(cb.max(root2.get("customerId")));

        Query query2 = session.createQuery(crt2);
        Object lastRowInserted = query2.getSingleResult();

        transaction.commit();
        session.close();
        if (lastRowInsertedInTemp == null) lastRowInsertedInTemp = (long) 0;
        if (lastRowInserted == null) lastRowInserted = (long) 0;


//        we have to check the max value in both the table because there can be a case that the data is authorized and not present
//        in temporary table but it is present in the master table so for that we have to take tha max value from both the tables
        return Math.max((long) lastRowInserted, (long) lastRowInsertedInTemp);
    }


    /* --------------------------------- Checker Actions --------------------------*/

    //      Checker views all Records
    @Override
    public List<CustomerTemp> checkerViewAllRecordsTempTable() {
        Session session = sessionFactory.openSession();
        List<CustomerTemp> customersList = session.createQuery("From CustomerTemp").list();
        session.close();
        return customersList;
    }

    //      Checker get single Record
    @Override
    public CustomerTemp checkerGetCustomerFromTemp(String customerCode) {
        Session session = sessionFactory.openSession();
        CustomerTemp customer = session.get(CustomerTemp.class, customerCode);
        session.close();
        return customer;
    }

    //    checker modifies a new record
    @Override
    public CustomerTemp checkerModifiesANewRecordTempTable(CustomerTemp customerTemp) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        session.update(customerTemp);
        transaction.commit();
        session.close();
        return customerTemp;
    }

    @Override
    public CustomerMaster checkerModifiesANewRecordMasterTable(CustomerMaster customerMaster) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        session.update(customerMaster);
        transaction.commit();
        session.close();
        return customerMaster;
    }

    //    checker adds a new record
    @Override
    public boolean checkerAddsCustomerInMasterTable(CustomerMaster customerMaster) {
//        copy the full object into a master table so i make a method to do this
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        customerMaster.setAuthorizedDate(LocalDate.now());
        session.save(customerMaster);

        transaction.commit();
        session.close();
        return true;
    }

    @Override
    public boolean checkerDeleteNewRecordMasterTable(String customerCode) {
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        CustomerMaster customer = session.get(CustomerMaster.class, customerCode);

        session.delete(customer);
        transaction.commit();
        session.close();
        return true;
    }
}
