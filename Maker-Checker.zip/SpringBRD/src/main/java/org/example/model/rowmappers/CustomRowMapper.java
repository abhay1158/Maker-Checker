package org.example.model.rowmappers;

import org.example.model.CustomerTemp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomRowMapper implements RowMapper<CustomerTemp> {

    @Autowired
    CustomerTemp customerTemp;

    @Override
    public CustomerTemp mapRow(ResultSet resultSet, int i) throws SQLException {
        customerTemp.setCustomerId(resultSet.getInt(1));
        customerTemp.setCustomerName(resultSet.getString(2));

        return customerTemp;
    }
}
