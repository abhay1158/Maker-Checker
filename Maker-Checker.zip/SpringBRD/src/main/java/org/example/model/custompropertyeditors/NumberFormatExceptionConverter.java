package org.example.model.custompropertyeditors;

import java.beans.PropertyEditorSupport;

public class NumberFormatExceptionConverter extends PropertyEditorSupport {
    @Override
    public void setAsText(String str) throws IllegalArgumentException {
        if (str == null || str.trim().equals("")) {
            setValue(0d); // you want to return double
        } else {
            setValue(Double.parseDouble(str));
        }
    }
}
