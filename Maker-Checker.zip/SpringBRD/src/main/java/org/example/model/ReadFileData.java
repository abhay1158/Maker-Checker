package org.example.model;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.example.service.ServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Component
public class ReadFileData {
    Logger logger = LogManager.getLogger(this.getClass());

    @Autowired
    private ServiceInterface serviceInterface;

    public List<CustomerTemp> checkValidData(MultipartFile file) {
        List<CustomerTemp> customerTemps = new ArrayList<>();
        try (InputStream inputStream = file.getInputStream()) {
            BufferedReader bf = new BufferedReader(new InputStreamReader(inputStream));
            String data;

            boolean allGood = true;
            while ((data = bf.readLine()) != null) {

                String[] record = data.split(",", -1);
                CustomerTemp customerTemp = new CustomerTemp();

                long currentCustomerId = serviceInterface.findTheLatestInsertedRowNumberTempTable();
                customerTemp.setCustomerId(currentCustomerId + 1);

//                for code
                if (serviceInterface.makerGetCustomerFromTemp(record[0]) == null && record[0] != null && record[0].matches("^[a-zA-Z0-9]*$")) {
                    customerTemp.setCustomerCode(record[0]);
                } else allGood = false;

//                for name
                if (record[1] != null && record[1].matches("^[A-Za-z\\s]+$")) {
                    customerTemp.setCustomerName(record[1]);
                } else allGood = false;

                customerTemp.setCustomerAddress1(record[2]);

                customerTemp.setCustomerAddress2(record[3]);
//                for pin code
                if (record[4] != null && record[4].length() == 6 && record[4].matches("^[1-9][0-9]{5}$")) {
                    customerTemp.setPinCode(Integer.parseInt(record[4]));
                } else allGood = false;

//                for email
                if (record[5] != null && record[5].matches("^[A-Za-z0-9_.-]+@(([A-Za-z]+\\d*)+)((\\.[A-Za-z]+\\d*)+)$")) {
                    customerTemp.setEmailAddress(record[5]);
                } else allGood = false;
//            for contact number
                if (record[6] != null && record[6].length() >= 10 && record[6].length() <= 20 && record[6].matches("(0/91)?[6-9][0-9]{9}")) {
                    customerTemp.setContactNumber(record[6]);
                } else allGood = false;

                customerTemp.setPrimaryContactPerson(record[7]);

                customerTemp.setActiveInactiveFlag(record[8]);

//                if all data is correct then
                if (allGood) {
                    customerTemps.add(customerTemp);
                } else {
                    logger.info("Record Rejected !! Not Validated");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return customerTemps;
    }
}
