package org.example.model;

import org.hibernate.annotations.Check;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;


import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.time.LocalDate;

@Component
@Entity
@Table(name = "CustomerMaster_kunalSinghBRD")
public class CustomerMaster {

    @Column(length = 10)
    private long customerId;

    @Column(nullable = false, length = 10)
    @Id
    @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "Customer Code contains only Alpha-Numerics")
    private String customerCode;
    @Column(nullable = false, length = 30)
    @Pattern(regexp = "^[A-Za-z\\s]+$", message = "Customer Name contains only Alpha-Numerics")
    private String customerName;
    @Column(nullable = false, length = 100)
    private String customerAddress1;
    @Column(length = 100)
    private String customerAddress2;
    @Column(nullable = false, length = 6)
    @Min(value = 6, message = "Invalid Pin Code")
    private int pinCode;
    @Column(nullable = false, length = 100)
    @Pattern(regexp = "^[A-Za-z0-9_.-]+@(([A-Za-z]+\\d*)+)((\\.[A-Za-z]+\\d*)+)$", message = "Entered E-Mail Address format is not correct")
    private String emailAddress;
    @Column(length = 20)
    @Size(min = 10, max = 20)
    @Pattern(regexp = "(0/91)?[7-9][0-9]{9}", message = "Invalid Contact Number")
    private String contactNumber;
    @Column(nullable = false, length = 100)
    private String primaryContactPerson;
    @Column(nullable = false, length = 5)
    private String recordStatus;
    @Column(nullable = false, length = 8)
    private String activeInactiveFlag;
    @Column(nullable = false, length = 30)
    private LocalDate createDate;
    @Column(nullable = false)
    private String createdBy;
    @Column(length = 30)
    private LocalDate modifiedDate;
    @Column
    private String modifiedBy;
    @Column(length = 30)
    private LocalDate authorizedDate;
    @Column
    private String authorizedBy;

    public long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerAddress1() {
        return customerAddress1;
    }

    public void setCustomerAddress1(String customerAddress1) {
        this.customerAddress1 = customerAddress1;
    }

    public String getCustomerAddress2() {
        return customerAddress2;
    }

    public void setCustomerAddress2(String customerAddress2) {
        this.customerAddress2 = customerAddress2;
    }

    public int getPinCode() {
        return pinCode;
    }

    public void setPinCode(int pinCode) {
        this.pinCode = pinCode;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getPrimaryContactPerson() {
        return primaryContactPerson;
    }

    public void setPrimaryContactPerson(String primaryContactPerson) {
        this.primaryContactPerson = primaryContactPerson;
    }

    public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getActiveInactiveFlag() {
        return activeInactiveFlag;
    }

    public void setActiveInactiveFlag(String activeInactiveFlag) {
        this.activeInactiveFlag = activeInactiveFlag;
    }

    public LocalDate getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDate createDate) {
        this.createDate = createDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDate getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(LocalDate modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public LocalDate getAuthorizedDate() {
        return authorizedDate;
    }

    public void setAuthorizedDate(LocalDate authorizedDate) {
        this.authorizedDate = authorizedDate;
    }

    public String getAuthorizedBy() {
        return authorizedBy;
    }

    public void setAuthorizedBy(String authorizedBy) {
        this.authorizedBy = authorizedBy;
    }

    @Override
    public String toString() {
        return "CustomerMaster{" +
                "customerId=" + customerId +
                ", customerCode='" + customerCode + '\'' +
                ", customerName='" + customerName + '\'' +
                ", customerAddress1='" + customerAddress1 + '\'' +
                ", customerAddress2='" + customerAddress2 + '\'' +
                ", pinCode=" + pinCode +
                ", emailAddress='" + emailAddress + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", primaryContactPerson='" + primaryContactPerson + '\'' +
                ", recordStatus='" + recordStatus + '\'' +
                ", activeInactiveFlag='" + activeInactiveFlag + '\'' +
                ", createDate=" + createDate +
                ", createdBy='" + createdBy + '\'' +
                ", modifiedDate=" + modifiedDate +
                ", modifiedBy='" + modifiedBy + '\'' +
                ", authorizedDate=" + authorizedDate +
                ", authorizedBy='" + authorizedBy + '\'' +
                '}';
    }
}